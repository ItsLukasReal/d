export default defineAppConfig({
  ui: {
    primary: 'purple',
    gray: 'cool',
  },
});
