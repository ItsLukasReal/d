# Papalatte Games

Auf dieser Seite werden die Spiele die Papaplatte noch spielen möchte getracked.
Da Kevin vorher auf unübersichtliche Bookmarks gesetzt hat, hab ich schnell diese Seite zusammen geschmissen.

![bookmarks auf einem desktop](docs/bookmarks.png)
